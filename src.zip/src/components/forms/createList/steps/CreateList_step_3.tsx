import FormRenderer from "../../../FormRenderer";
import { getListExitStrategySchema } from "../../../../schemas/create-list/schema_step_3";
import useAppStore from "../../../../store/useAppStore";

import { transformToSnakeCase } from "../../../../utils/transformCase";

const CreateList_step_3 = ({
  onPrevious,
  onConfirm,
}: {
  onPrevious: () => void;
  onConfirm: (data: any) => {};
}) => {
  const settings = useAppStore((state) => state.settings);
  const { callResults } = settings!["Phone Settings"];

  const extendedCallResults = callResults.map((callResult: any) => {
    return { ...callResult, value: transformToSnakeCase(callResult.label) };
  });

  const listExitStrategySchema = getListExitStrategySchema(extendedCallResults);

  return (
    <FormRenderer
      schema={listExitStrategySchema}
      onPrevious={onPrevious}
      onSubmit={onConfirm}
    />
  );
};

export default CreateList_step_3;
