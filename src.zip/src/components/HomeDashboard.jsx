

  // there will be HomeDashboard dashboard component that will be used to display the dashboard for the home 
  // page who is showed now in main dashboard component 

const HomeDashboard = () => { 
  return (
    <div></div>
  )
}

export default HomeDashboard