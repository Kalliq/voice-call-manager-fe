type CallResult = {
  id: string;
  label: string;
  checked: boolean;
};

export { CallResult };
