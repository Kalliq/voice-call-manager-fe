export enum ButtonAction {
  NEXT = "next",
  PREVIOUS = "previous",
  SUBMIT = "submit",
}
